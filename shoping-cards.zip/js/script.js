const button = document.getElementById("heart-like-button");

button.addEventListener("click", () => {
    if (button.classList.contains("liked")) {
        button.classList.remove("liked");
    } else {
        button.classList.add("liked");
    }
});


const button2 = document.getElementById ("heart-like-button2");

button2.addEventListener("click", () => {
    if (button2.classList.contains("liked")) {
        button2.classList.remove("liked");
    } else {
        button2.classList.add("liked");
    }
});

const button3 = document.getElementById ("heart-like-button3");

button3.addEventListener("click", () => {
    if (button3.classList.contains("liked")) {
        button3.classList.remove("liked");
    } else {
        button3.classList.add("liked");
    }
});



var i = 1;
var prix = 900
document.getElementById("myBtn").addEventListener("click", function () {
   
    
    let Q = document.getElementById("Quantity");
    const PRO = document.getElementById("Product");
    const price = document.getElementById("Price");
    Q.innerHTML = i++;
    PRO.innerText = "Iphone";
    price.innerHTML = prix* (i-1) + "$";
    if (i >= 12) {
        return alert('You have reached to max order "10"');
    }


});



document.getElementById("rmBtn").addEventListener("click", function () {
    
   
    let Q = document.getElementById("Quantity");
    const PRO = document.getElementById("Product");
    const price = document.getElementById("Price");
    Q.innerHTML = i--;
    PRO.innerText = "Iphone";
    price.innerHTML = prix *i + "$";
    if (i >= 12) {
        return alert('You have reached to max order "10"');
    }


});


var j = 1;
var prix2 = 800

document.getElementById("myBtn2").addEventListener("click", function () {
   
    
    let Q = document.getElementById("Quantity2");
    const PRO = document.getElementById("Product2");
    const price = document.getElementById("Price2");
    Q.innerHTML = j++;
    PRO.innerText = "Samsung";
    price.innerHTML = prix2* (j-1) + "$";
    if (j >= 12) {
        return alert('You have reached to max order "10"');
    }


});

var k =1;
let prix3 = 700;
document.getElementById("myBtn3").addEventListener("click", function () {
   
    
    let Q = document.getElementById("Quantity3");
    const PRO = document.getElementById("Product3");
    const price = document.getElementById("Price3");
    Q.innerHTML = k++;
    PRO.innerText = "Huewei";
    price.innerHTML = prix3 * (k-1) + "$";
    if (k >= 12) {
        return alert('You have reached to max order "10"');
    }


});





