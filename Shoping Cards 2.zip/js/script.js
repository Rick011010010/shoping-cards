const button = document.getElementById("heart-like-button");

button.addEventListener("click", () => {
    if (button.classList.contains("liked")) {
        button.classList.remove("liked");
    } else {
        button.classList.add("liked");
    }
});


const button2 = document.getElementById("heart-like-button2");

button2.addEventListener("click", () => {
    if (button2.classList.contains("liked")) {
        button2.classList.remove("liked");
    } else {
        button2.classList.add("liked");
    }
});

const button3 = document.getElementById("heart-like-button3");

button3.addEventListener("click", () => {
    if (button3.classList.contains("liked")) {
        button3.classList.remove("liked");
    } else {
        button3.classList.add("liked");
    }
});



var i = 1;
var prix = 900;
document.getElementById("myBtn").addEventListener("click", function () {

    if (i < 11) {
        let Q = document.getElementById("Quantity");
        const PRO = document.getElementById("Product");
        const price = document.getElementById("Price");
        const icon = document.getElementById("icon")
        let rm= i++;
        Q.innerHTML = rm;
        PRO.innerText = "Iphone";
        price.innerHTML = prix * (i - 1) + "$";
    }

    if (i >= 11) {
        return alert('You have reached to the max order for today"10 Iphones"');
    }


});




document.getElementById("rmBtn").addEventListener("click", function () {
        
    if (i > 0) {
        let Q = document.getElementById("Quantity");
        const PRO = document.getElementById("Product");
        const price = document.getElementById("Price");
        let rm= i--;
        Q.innerHTML = rm-1;
        PRO.innerText = "Iphone";
        price.innerHTML = prix * i + "$";
    }

    if (i <= 0) {
        return alert('All your orders are removed');
        
    }


});


var j = 1;
var prix2 = 800

document.getElementById("myBtn2").addEventListener("click", function () {

    if (j < 11) {
        let Q = document.getElementById("Quantity2");
        const PRO = document.getElementById("Product2");
        const price = document.getElementById("Price2");
        Q.innerHTML = j++;
        PRO.innerText = "Samsung";
        price.innerHTML = prix2 * (j - 1) + "$";
    }

    if (j >= 11) {
        return alert('You have reached to the max order for today "10 Samsungs"');
    }


});

document.getElementById("rmBtn2").addEventListener("click", function () {

    if (j > 0) {
        let Q = document.getElementById("Quantity2");
        const PRO = document.getElementById("Product2");
        const price = document.getElementById("Price2");
        let rm= j--;
        Q.innerHTML = rm-1;
        PRO.innerText = "Samsung";
        price.innerHTML = prix2 * j + "$";
    }

    if (j <= 0) {
        return alert('All your orders are removed');
    }



});





var k = 1;
let prix3 = 700;
document.getElementById("myBtn3").addEventListener("click", function () {

    if (k < 11) {
        let Q = document.getElementById("Quantity3");
        const PRO = document.getElementById("Product3");
        const price = document.getElementById("Price3");
        Q.innerHTML = k++;
        PRO.innerText = "Huewei";
        price.innerHTML = prix3 * (k - 1) + "$";
    }

    if (k >= 11) {
        return alert('You have reached to the max order for today "10 Huewei phones"');
    }


});



document.getElementById("rmBtn3").addEventListener("click", function () {

    if (k > 0) {
        let Q = document.getElementById("Quantity3");
        const PRO = document.getElementById("Product3");
        const price = document.getElementById("Price3");
        let rm= k--;
        Q.innerHTML = rm-1;
        PRO.innerText = "Huewei";
        price.innerHTML = prix3 * k + "$";
    }

    if (k <= 0) {
        return alert('All your orders are removed');

    }


});





