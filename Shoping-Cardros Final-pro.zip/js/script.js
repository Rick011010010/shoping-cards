// gets a reference to the heartDOm
const heartDOM = document.querySelector('.js-heart');
// initialized like to false when user hasnt selected
let liked = false;

// create a onclick listener
heartDOM.onclick = (event) => {
	// check if liked 
	liked = !liked; // toggle the like ( flipping the variable)
	
	// this is what we clicked on
	const target = event.currentTarget;
	
	if (liked) {
		// remove empty heart if liked and add the full heart
		target.classList.remove('far');
		target.classList.add('fas', 'pulse');
	} else {
		// remove full heart if unliked and add empty heart
		target.classList.remove('fas');
		target.classList.add('far');
	}
}

heartDOM.addEventListener('animationend', (event) => {
	event.currentTarget.classList.remove('pulse');
})

// gets a reference to the heartDOm
const heartDOM2 = document.getElementById('heart2');
// initialized like to false when user hasnt selected

// create a onclick listener
heartDOM2.onclick = (event) => {
	// check if liked 
	liked = !liked; // toggle the like ( flipping the variable)
	
	// this is what we clicked on
	const target = event.currentTarget;
	
	if (liked) {
		// remove empty heart if liked and add the full heart
		target.classList.remove('far');
		target.classList.add('fas', 'pulse');
	} else {
		// remove full heart if unliked and add empty heart
		target.classList.remove('fas');
		target.classList.add('far');
	}
}

heartDOM2.addEventListener('animationend', (event) => {
	event.currentTarget.classList.remove('pulse');
})



// gets a reference to the heartDOm
const heartDOM3 = document.getElementById('heart3');
// initialized like to false when user hasnt selected

// create a onclick listener
heartDOM3.onclick = (event) => {
	// check if liked 
	liked = !liked; // toggle the like ( flipping the variable)
	
	// this is what we clicked on
	const target = event.currentTarget;
	
	if (liked) {
		// remove empty heart if liked and add the full heart
		target.classList.remove('far');
		target.classList.add('fas', 'pulse');
	} else {
		// remove full heart if unliked and add empty heart
		target.classList.remove('fas');
		target.classList.add('far');
	}
}

heartDOM3.addEventListener('animationend', (event) => {
	event.currentTarget.classList.remove('pulse');
})




// IPHONE  card
var i = 1;
var prix = 900;
document.getElementById("myBtn").addEventListener("click", function () {

    if (i < 11) {
        let Q = document.getElementById("Quantity");
        const PRO = document.getElementById("Product");
        const price = document.getElementById("Price");
        const icon = document.getElementById("icon")
        let rm= i++;
        Q.innerHTML = rm;
        PRO.innerText = "Iphone";
        price.innerHTML = prix * (i - 1) + "$";
        let total = price
    }

    if (i >= 11) {
        return alert('You have reached to the max order for today"10 Iphones"');
    }


});




document.getElementById("rmBtn").addEventListener("click", function () {
        
    if (i > 0) {
        let Q = document.getElementById("Quantity");
        const PRO = document.getElementById("Product");
        const price = document.getElementById("Price");
        let rm= i--;
        Q.innerHTML = rm-1;
        PRO.innerText = "Iphone";
        price.innerHTML = prix * i + "$";
    }

    if (i <= 0) {
        return alert('All your orders are removed');
        
    }


});

//Samsung card
var j = 1;
var prix2 = 800

document.getElementById("myBtn2").addEventListener("click", function () {

    if (j < 11) {
        let Q = document.getElementById("Quantity2");
        const PRO = document.getElementById("Product2");
        const price = document.getElementById("Price2");
        Q.innerHTML = j++;
        PRO.innerText = "Samsung";
        price.innerHTML = prix2 * (j - 1) + "$";
    }

    if (j >= 11) {
        return alert('You have reached to the max order for today "10 Samsungs"');
    }


});

document.getElementById("rmBtn2").addEventListener("click", function () {

    if (j > 0) {
        let Q = document.getElementById("Quantity2");
        const PRO = document.getElementById("Product2");
        const price = document.getElementById("Price2");
        let rm= j--;
        Q.innerHTML = rm-1;
        PRO.innerText = "Samsung";
        price.innerHTML = prix2 * j + "$";
    }

    if (j <= 0) {
        return alert('All your orders are removed');
    }



});




// huewei card
var k = 1;
let prix3 = 700;
document.getElementById("myBtn3").addEventListener("click", function () {

    if (k < 11) {
        let Q = document.getElementById("Quantity3");
        const PRO = document.getElementById("Product3");
        const price = document.getElementById("Price3");
        Q.innerHTML = k++;
        PRO.innerText = "Huewei";
        price.innerHTML = prix3 * (k - 1) + "$";
    }

    if (k >= 11) {
        return alert('You have reached to the max order for today "10 Huewei phones"');
    }


});



document.getElementById("rmBtn3").addEventListener("click", function () {

    if (k > 0) {
        let Q = document.getElementById("Quantity3");
        const PRO = document.getElementById("Product3");
        const price = document.getElementById("Price3");
        let rm= k--;
        Q.innerHTML = rm-1;
        PRO.innerText = "Huewei";
        price.innerHTML = prix3 * k + "$";
    }

    if (k <= 0) {
        return alert('All your orders are removed');

    }


});



document.getElementsByClassName("pannier")()





